# Enclosure design notes

- Separate manufactured parts: `base.kcl` and `lid.kcl`, assembled in `main.kcl`.
- Assembled outer radius: 83 mm (166 mm diameter); height: 25 mm.
- Base floor and lid roof: 3 mm. Lid seats at Z=17 mm, with 5 mm neck engagement.
- Screw-on interface is a nominal cylindrical representation ONLY: base neck radius 79.5 mm, lid socket radius 79.8 mm. Helical threads, thread profile, pitch and manufacturing fit are not yet defined. Smooth exported parts will not screw together.
- Four integral PCB standoffs: 8 mm diameter, 6 mm above the floor, on a provisional 90 x 90 mm square mounting pattern.
- Standoff blind pilot holes: diameter 2.6 mm, depth 6 mm, leaving the 3 mm floor intact. Screw type/material and PCB mounting pattern require confirmation; pilots are not a validated tapping specification.
- `lidLift` in main.kcl defaults to zero; increase for exploded inspection.
- Both part files execute; all seven sketches are fully constrained. Assembly executes. Base cavity, pilots and lid socket are boolean-subtracted voids. No manufacturing/process validation performed.
